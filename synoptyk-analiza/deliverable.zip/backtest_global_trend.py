"""
backtest_global_trend.py
==========================
Scenariusz "synoptyka" w skali globalnej: katalog M6.3+, 2016-01-01 .. 2026-08-15
(699 realnych zdarzen, zweryfikowane 1:1 z licznikiem USGS fdsnws/event/count).

Trzy testy:
1. anomalies() -- kontrola pozytywna: czy najwieksze wstrzasy (M7.5+) sa
   poprawnie wykrywane jako anomalie na tle calego katalogu?
2. rhythm() -- kontrola negatywna: sejsmicznosc globalna M6.3+ powinna byc
   w przyblizeniu procesem Poissona (brak periodycznosci). Test na 699
   realnych zdarzeniach (repo mial wczesniej tylko test na probce 64 zdarzen).
3. WALK-FORWARD: czy trend_z (catalog_core.trend, liczony WYLACZNIE na
   danych SPRZED danego dnia) niesie jakakolwiek informacje o LICZBIE
   zdarzen M6.3+ w kolejnych 30 dniach -- w porownaniu do:
     (a) prognozy Poissona z tempa ostatnich 90 dni ("Poisson-persystencja")
     (b) prognozy = dlugoterminowa srednia z calej historii do tego dnia
   Ocena: korelacja out-of-sample z realna liczba zdarzen w kolejnych 30
   dniach, sredni blad bezwzgledny (MAE), i - dla rzadszego progu M7.0+ -
   Brier score na "czy bedzie >=1 zdarzenie M7.0+ w kolejnych 30 dniach".
"""
import csv
import numpy as np
from catalog_core import TIMDRCatalogFusion

DAY_MS = 86400_000

rows = []
with open('data/global/merged_m6.3.csv') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append((float(row['mag']), int(row['time_ms']), row['place']))
rows.sort(key=lambda x: x[1])

mags = np.array([r[0] for r in rows])
times_ms = np.array([r[1] for r in rows])
t0 = times_ms[0]
t_days = (times_ms - t0) / DAY_MS

cat = TIMDRCatalogFusion()

print(f"Katalog: {len(rows)} zdarzen M6.3+, {t_days[-1]/365.25:.2f} lat "
      f"({len(rows)/(t_days[-1]/365.25):.1f} zdarzen/rok)")

# ============================================================
# 1. anomalies() -- kontrola pozytywna
# ============================================================
print("\n=== 1. anomalies() na 699 realnych zdarzeniach M6.3+ ===")
idx, z = cat.anomalies(mags)
order = idx[np.argsort(-z[idx])]
print(f"Wykryto {len(idx)} anomalii (|MAD-z| > 3.0) na {len(mags)} zdarzen:")
for i in order[:10]:
    import datetime
    dt = datetime.datetime.utcfromtimestamp(times_ms[i] / 1000)
    print(f"  M{mags[i]:.1f}  z={z[i]:6.2f}  {dt:%Y-%m-%d}  {rows[i][2]}")
top10_real_mag = sorted(mags)[-10:]
print(f"10 najwiekszych zdarzen w katalogu (real): {sorted(top10_real_mag, reverse=True)}")

# ============================================================
# 2. rhythm() -- kontrola negatywna (spodziewany brak periodycznosci)
# ============================================================
print("\n=== 2. rhythm() na 699 realnych zdarzeniach (oczekiwane: brak okresowosci) ===")
periods, score = cat.rhythm(mags, max_lag=60, power_thresh=0.4)
print(f"Wykryte 'okresy' (w zdarzeniach, nie w czasie): {periods}, score={score:.3f}")
print("(score < 0.4 = brak wykrytej periodycznosci, zgodnie z oczekiwaniem: "
      "globalna sejsmicznosc M6.3+ ~ proces Poissona)")

# ============================================================
# 3. WALK-FORWARD: trend_z jako predyktor liczby zdarzen w kolejnych 30 dniach
# ============================================================
print("\n=== 3. WALK-FORWARD: prognoza liczby zdarzen M6.3+ w kolejnych 30 dniach ===")

WINDOW_FWD = 30.0   # dni w przod (cel prognozy)
WINDOW_BACK = 90.0  # dni wstecz (do estymacji tempa i trend_z)
STEP = 15.0         # co ile dni robimy kolejny punkt prognozy
BURN_IN = 365.0     # pierwszy rok tylko do "rozgrzania" (kalibracja historyczna)

long_run_rate = None  # aktualizowane kroczaco (tylko dane < D)

forecast_days = np.arange(BURN_IN, t_days[-1] - WINDOW_FWD, STEP)

real_counts = []
poisson90_pred = []
longrun_pred = []
trend_z_at_D = []

for D in forecast_days:
    past_mask = t_days < D
    past_t = t_days[past_mask]
    past_mag = mags[past_mask]

    # (a) Poisson-persystencja: tempo z ostatnich 90 dni PRZED D
    recent_mask = (past_t >= D - WINDOW_BACK) & (past_t < D)
    recent_rate = recent_mask.sum() / WINDOW_BACK
    poisson90_pred.append(recent_rate * WINDOW_FWD)

    # (b) dlugoterminowa srednia ze WSZYSTKICH danych sprzed D
    longrun_rate = len(past_t) / D if D > 0 else 0.0
    longrun_pred.append(longrun_rate * WINDOW_FWD)

    # (c) trend_z z catalog_core.trend(), liczony WYLACZNIE na danych sprzed D
    if len(past_t) >= 20:
        slopes, tz = cat.trend(past_t, past_mag, window=20)
        trend_z_at_D.append(tz[-1])
    else:
        trend_z_at_D.append(0.0)

    # REALNA liczba zdarzen w [D, D+30) -- dane z przyszlosci wzgledem D,
    # uzyte TYLKO do oceny, nie do prognozy
    real = int(((t_days >= D) & (t_days < D + WINDOW_FWD)).sum())
    real_counts.append(real)

real_counts = np.array(real_counts)
poisson90_pred = np.array(poisson90_pred)
longrun_pred = np.array(longrun_pred)
trend_z_at_D = np.array(trend_z_at_D)

print(f"Liczba punktow walk-forward: {len(forecast_days)} "
      f"(co {STEP:.0f} dni, {forecast_days[0]:.0f}..{forecast_days[-1]:.0f} dni od poczatku katalogu)")

# --- czy trend_z koreluje z REALNA przyszla liczba zdarzen? ---
corr_trend_vs_real = np.corrcoef(trend_z_at_D, real_counts)[0, 1]
corr_poisson_vs_real = np.corrcoef(poisson90_pred, real_counts)[0, 1]
print(f"\nKorelacja trend_z(D) [tylko dane<D] z realna liczba zdarzen w [D,D+30d]: "
      f"r={corr_trend_vs_real:.3f}")
print(f"Korelacja prognozy Poisson-90d z realna liczba zdarzen: r={corr_poisson_vs_real:.3f}")

mae_poisson = np.mean(np.abs(poisson90_pred - real_counts))
mae_longrun = np.mean(np.abs(longrun_pred - real_counts))
print(f"\nMAE Poisson-90d-persystencja: {mae_poisson:.2f} zdarzen")
print(f"MAE dlugoterminowa-srednia:   {mae_longrun:.2f} zdarzen")
print(f"(realna srednia liczba zdarzen w oknie 30d: {real_counts.mean():.2f}, "
      f"std: {real_counts.std():.2f})")

# --- prognoza "TIMDR-adjusted": Poisson-90d skalowany przez trend_z ---
# proste, przejrzyste przeskalowanie (nie ML): rate_adj = rate90 * (1 + alpha*trend_z)
# alpha dobrany TYLKO na pierwszej polowie danych (in-sample), test na drugiej
# polowie (out-of-sample) - zeby uczciwie sprawdzic czy to cokolwiek daje.
half = len(forecast_days) // 2
alpha_candidates = np.linspace(-0.3, 0.3, 61)
best_alpha, best_mae_in = 0.0, mae_poisson
for a in alpha_candidates:
    adj = poisson90_pred[:half] * np.clip(1 + a * trend_z_at_D[:half], 0, None)
    mae_in = np.mean(np.abs(adj - real_counts[:half]))
    if mae_in < best_mae_in:
        best_mae_in, best_alpha = mae_in, a

adj_out = poisson90_pred[half:] * np.clip(1 + best_alpha * trend_z_at_D[half:], 0, None)
mae_adj_out = np.mean(np.abs(adj_out - real_counts[half:]))
mae_poisson_out = np.mean(np.abs(poisson90_pred[half:] - real_counts[half:]))
print(f"\nOut-of-sample test (alpha={best_alpha:.3f} dobrane na 1. polowie danych):")
print(f"  MAE Poisson-90d (2. polowa, out-of-sample):        {mae_poisson_out:.2f}")
print(f"  MAE Poisson-90d + korekta trend_z (out-of-sample):  {mae_adj_out:.2f}")
improvement = (mae_poisson_out - mae_adj_out) / mae_poisson_out * 100
print(f"  Poprawa dzieki trend_z: {improvement:+.1f}%")

# ============================================================
# 4. Rzadszy prog M7.0+: Brier score dla ">=1 zdarzenie w 30 dniach"
# ============================================================
print("\n=== 4. Brier score: P(>=1 zdarzenie M7.0+ w kolejnych 30 dniach) ===")
mag_thresh = 7.0
real_ge = []
poisson_p = []
for i, D in enumerate(forecast_days):
    past_mask = t_days < D
    past_t7 = t_days[past_mask][mags[past_mask] >= mag_thresh]
    recent7 = past_t7[(past_t7 >= D - WINDOW_BACK) & (past_t7 < D)]
    rate7 = len(recent7) / WINDOW_BACK
    p_atleast1 = 1 - np.exp(-rate7 * WINDOW_FWD)  # Poisson
    poisson_p.append(p_atleast1)
    real7 = int(((t_days >= D) & (t_days < D + WINDOW_FWD) & (mags >= mag_thresh)).sum() > 0)
    real_ge.append(real7)

real_ge = np.array(real_ge)
poisson_p = np.array(poisson_p)
brier_poisson = np.mean((poisson_p - real_ge) ** 2)
brier_climatology = np.mean((real_ge.mean() - real_ge) ** 2)  # stala prognoza = baza-rate
print(f"Baza-rate P(>=1 M7.0+ w 30d) w probie: {real_ge.mean():.3f}")
print(f"Brier score - stala prognoza (baza-rate/'klimatologia'): {brier_climatology:.4f}")
print(f"Brier score - Poisson z tempa 90-dniowego:                {brier_poisson:.4f}")
print("(Brier score: 0=idealna prognoza, nizszy=lepszy; test czy Poisson bije "
      "'zawsze taka sama' prognoze klimatologiczna)")
