import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

plt.rcParams.update({
    'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.edgecolor': '#888888', 'axes.labelcolor': '#333333',
    'xtick.color': '#555555', 'ytick.color': '#555555',
    'figure.facecolor': 'white', 'axes.facecolor': 'white',
})

COL_REAL = '#1a1a1a'
COL_OMORI = '#2b6cb0'
COL_POISSON = '#c2410c'
COL_NAIVE = '#9ca3af'

# ---------------------------------------------------------------
# Chart 1: Ridgecrest -- rzeczywista stopa aftershockow + dopasowanie Omori
# ---------------------------------------------------------------
MAINSHOCK_T = 1562383193040
DAY_MS = 86400_000
rows = []
with open('data/ridgecrest/merged_m4.0.csv') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append((float(row['mag']), int(row['time_ms'])))
rows.sort(key=lambda x: x[1])
times = np.array([r[1] for r in rows])
t_days = (times - MAINSHOCK_T) / DAY_MS
aft_t = t_days[t_days > 0]

def omori(t, K, c, p):
    return K / (t + c) ** p

def log_omori(t, logK, c, p):
    return logK - p * np.log(t + c)

bins = np.arange(0, 48.25, 0.25)
counts, edges = np.histogram(aft_t, bins=bins)
centers = (edges[:-1] + edges[1:]) / 2
rate_obs = counts / 0.25

# fit w przestrzeni LOG na calosci danych (do rysunku - pelny widok; backtest
# w osobnym pliku uzywa kauzalnych okien danych, patrz raport)
mask = rate_obs > 0
popt_log, _ = curve_fit(log_omori, centers[mask], np.log(rate_obs[mask]),
                         p0=[np.log(3), 0.1, 1.0], bounds=([-10, 1e-4, 0.3], [15, 10, 2.5]), maxfev=20000)
popt = np.array([np.exp(popt_log[0]), popt_log[1], popt_log[2]])
t_smooth = np.linspace(0.05, 12, 300)
rate_smooth = omori(t_smooth, *popt)

background_rate = 22 / 1.4  # z backtestu -- tlo z okresu foreshock->mainshock (patrz zastrzezenie w raporcie)

fig, ax = plt.subplots(figsize=(9.5, 5.5))
ax.scatter(centers[mask], rate_obs[mask], s=18, color=COL_REAL, alpha=0.75,
           label='Rzeczywiste dane (USGS), zdarzenia/dzień w oknach 6h', zorder=3)
ax.plot(t_smooth, rate_smooth, color=COL_OMORI, lw=2,
         label=f'Dopasowanie Omori-Utsu: K={popt[0]:.2f}, c={popt[1]:.2f}, p={popt[2]:.2f}', zorder=2)
ax.axhline(background_rate, color=COL_POISSON, lw=1.5, ls='--',
           label=f'Poziom tła sprzed mainshocku (~{background_rate:.1f}/dzień)', zorder=1)
ax.set_yscale('log')
ax.set_xlabel('Dni od mainshocku M7.1 (2019-07-06)')
ax.set_ylabel('Tempo wstrząsów wtórnych M4.0+ (zdarzeń/dzień)')
ax.set_title('Sekwencja Ridgecrest 2019 — rzeczywisty zanik aftershocków vs prawo Omori-Utsu', fontsize=12)
ax.legend(fontsize=8.5, loc='upper right')
ax.set_ylim(0.05, 250)
fig.tight_layout()
fig.savefig('chart_ridgecrest_omori.png', dpi=150)
print('saved chart_ridgecrest_omori.png')

# ---------------------------------------------------------------
# Chart 2: global walk-forward -- prognoza vs realna liczba zdarzen (30d)
# ---------------------------------------------------------------
from catalog_core import TIMDRCatalogFusion
rows2 = []
with open('data/global/merged_m6.3.csv') as f:
    r = csv.DictReader(f)
    for row in r:
        rows2.append((float(row['mag']), int(row['time_ms'])))
rows2.sort(key=lambda x: x[1])
mags = np.array([r[0] for r in rows2])
times2 = np.array([r[1] for r in rows2])
t_days2 = (times2 - times2[0]) / DAY_MS

WINDOW_FWD, WINDOW_BACK, STEP, BURN_IN = 30.0, 90.0, 15.0, 365.0
forecast_days = np.arange(BURN_IN, t_days2[-1] - WINDOW_FWD, STEP)
real_counts, poisson_pred = [], []
for D in forecast_days:
    past_t = t_days2[t_days2 < D]
    recent = past_t[(past_t >= D - WINDOW_BACK) & (past_t < D)]
    poisson_pred.append(len(recent) / WINDOW_BACK * WINDOW_FWD)
    real_counts.append(int(((t_days2 >= D) & (t_days2 < D + WINDOW_FWD)).sum()))
real_counts = np.array(real_counts)
poisson_pred = np.array(poisson_pred)
r_val = np.corrcoef(poisson_pred, real_counts)[0, 1]

fig2, ax2 = plt.subplots(figsize=(6.2, 6))
ax2.scatter(poisson_pred, real_counts, s=22, color=COL_POISSON, alpha=0.55, edgecolor='none')
lims = [0, max(poisson_pred.max(), real_counts.max()) + 1]
ax2.plot(lims, lims, color=COL_REAL, lw=1, ls='--', label='idealna prognoza (y=x)')
ax2.set_xlim(lims); ax2.set_ylim(lims)
ax2.set_xlabel('Prognoza (tempo z ostatnich 90 dni × 30)')
ax2.set_ylabel('Rzeczywista liczba zdarzeń M6.3+ w kolejnych 30 dniach')
ax2.set_title(f'Katalog globalny 2016–2026 — prognoza vs rzeczywistość\n(walk-forward, n={len(forecast_days)}, r={r_val:.3f})')
ax2.legend(fontsize=9)
ax2.set_aspect('equal')
fig2.tight_layout()
fig2.savefig('chart_global_walkforward.png', dpi=150)
print('saved chart_global_walkforward.png')
