"""
backtest_ridgecrest_omori.py
=============================
Test scenariusza "synoptyka" na prawdziwej sekwencji Ridgecrest 2019 (USGS,
M4.0+, box 35.4-36.1N / -117.9..-117.2E, 2019-06-01 .. 2019-09-01).

Pytanie: mając dane TYLKO do chwili t_f (bez zaglądania w przyszłość), na ile
można prognozować liczbę wstrząsów wtórnych M>=4.0 w kolejnym oknie czasu?

Metoda: klasyczne prawo Omori-Utsu, dopasowywane KAUZALNIE (tylko na
zdarzeniach sprzed t_f) do sekwencji po głównym wstrząsie M7.1
(2019-07-06 03:19:53 UTC, t0=1562383193040 ms):

    rate(t) = K / (t + c)^p      [wstrząsy / dzień, t = dni od mainshocku]

Prognoza liczby zdarzeń w oknie [t_f, t_f+dt]:
    N_forecast = integral_{t_f}^{t_f+dt} rate(t) dt

Baseline 1 (Poisson tła): stała stopa z 33 dni PRZED mainshockiem (prawdziwe
tło sejsmiczne regionu, bez wstrząsów wtórnych).
Baseline 2 (naiwna persystencja): stopa z ostatnich 24h przed t_f, założona
jako stała na okno prognozy.

Wynik oceniany na REALNYCH, faktycznie zaobserwowanych zdarzeniach w oknie
[t_f, t_f+dt] (dane, które w momencie prognozy jeszcze nie istniały).
"""
import csv
import numpy as np
from scipy.optimize import curve_fit

MAINSHOCK_T = 1562383193040  # 2019-07-06 03:19:53.040 UTC, M7.1
DAY_MS = 86400_000

rows = []
with open('data/ridgecrest/merged_m4.0.csv') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append((float(row['mag']), int(row['time_ms']), row['place']))
rows.sort(key=lambda x: x[1])

mags = np.array([r[0] for r in rows])
times = np.array([r[1] for r in rows])
t_days = (times - MAINSHOCK_T) / DAY_MS  # dni wzgledem mainshocku (moze byc ujemne)

# --- tlo przed mainshockiem (33 dni, 2019-06-01 -> mainshock) ---
pre = t_days[t_days < 0]
pre_span_days = -pre.min() if len(pre) else 33.0
background_rate = len(pre) / pre_span_days  # zdarzen/dzien, prawdziwe tlo
print(f"Tlo przed mainshockiem: {len(pre)} zdarzen w {pre_span_days:.1f} dniach "
      f"-> {background_rate:.4f} zdarzen/dzien")

# --- aftershocki (t>0), wylaczajac sam mainshock ---
aft_mask = t_days > 0
aft_t = t_days[aft_mask]
print(f"Aftershocki M4.0+ w oknie danych: {len(aft_t)}, "
      f"do t={aft_t.max():.1f} dni po mainshocku")


def omori(t, K, c, p):
    return K / (t + c) ** p


def log_omori(t, logK, c, p):
    return logK - p * np.log(t + c)


def fit_omori_causal(aft_t_observed, t_fit_cutoff):
    """Dopasuj Omori-Utsu uzywajac WYLACZNIE aftershockow z aft_t_observed
    ktore wystapily przed t_fit_cutoff (dni od mainshocku). Zwraca (K,c,p)
    lub None jesli za malo danych.

    Dopasowanie w przestrzeni LOG (log-rate vs t), nie w przestrzeni liniowej:
    surowe najmniejsze kwadraty na rate() sa zdominowane przez ogromny,
    krotkotrwaly szczyt tuz po mainshocku (setki zdarzen/dzien) i praktycznie
    ignoruja ogon rozkladu (pojedyncze zdarzenia/dzien, dni pozniej) - dajac
    krzywa ktora dobrze pasuje do pierwszych godzin i kompletnie nie pasuje
    do reszty sekwencji. Dopasowanie log-rate wazy kazdy rzad wielkosci
    rownomiernie, co jest standardowym podejsciem przy dopasowywaniu
    rozkladow potegowych (Omori-Utsu) i daje krzywa faktycznie sledzaca caly
    zaobserwowany zanik, nie tylko pierwsze godziny."""
    obs = aft_t_observed[aft_t_observed < t_fit_cutoff]
    if len(obs) < 8:
        return None
    bins = np.arange(0, t_fit_cutoff + 0.25, 0.25)  # kwadranse dnia
    if len(bins) < 4:
        return None
    counts, edges = np.histogram(obs, bins=bins)
    centers = (edges[:-1] + edges[1:]) / 2
    width = edges[1] - edges[0]
    rate_obs = counts / width
    mask = rate_obs > 0
    if mask.sum() < 4:
        return None
    try:
        popt_log, _ = curve_fit(
            log_omori, centers[mask], np.log(rate_obs[mask]),
            p0=[np.log(max(rate_obs[mask].max(), 1.0)), 0.1, 1.0],
            bounds=([-10, 1e-4, 0.3], [15, 10, 2.5]),
            maxfev=20000,
        )
        logK, c, p = popt_log
        return np.array([np.exp(logK), c, p])
    except Exception:
        return None


def integral_omori(K, c, p, t0, t1):
    if abs(p - 1.0) < 1e-6:
        return K * (np.log(t1 + c) - np.log(t0 + c))
    return K / (1 - p) * ((t1 + c) ** (1 - p) - (t0 + c) ** (1 - p))


# --- punkty prognozy: forecast w chwili t_f, na okno [t_f, t_f+window] ---
forecast_points = [
    (0.25, 0.75),   # po 6h -> prognoza na kolejne 18h (do t=1d)
    (1.0, 1.0),     # po 1d -> prognoza na kolejny 1d
    (2.0, 1.0),     # po 2d -> prognoza na kolejny 1d
    (3.0, 2.0),     # po 3d -> prognoza na kolejne 2d
    (5.0, 2.0),     # po 5d -> prognoza na kolejne 2d
    (7.0, 3.0),     # po 7d -> prognoza na kolejne 3d
    (10.0, 4.0),    # po 10d -> prognoza na kolejne 4d
]

print("\n=== BACKTEST: prognoza liczby wstrzasow wtornych M4.0+ ===")
print(f"{'t_f':>6} {'okno':>6} {'obserwacje<t_f':>14} {'Omori K,c,p':>22} "
      f"{'Omori_pred':>11} {'Poisson_tlo':>12} {'naive_24h':>10} {'REALNE':>7}")

results = []
for t_f, window in forecast_points:
    popt = fit_omori_causal(aft_t, t_f)
    real_count = int(((aft_t >= t_f) & (aft_t < t_f + window)).sum())
    poisson_pred = background_rate * window
    last24 = aft_t[(aft_t >= max(0, t_f - 1.0)) & (aft_t < t_f)]
    naive_rate = len(last24) / min(1.0, t_f)
    naive_pred = naive_rate * window

    if popt is not None:
        K, c, p = popt
        omori_pred = integral_omori(K, c, p, t_f, t_f + window)
        omori_str = f"K={K:.2f},c={c:.2f},p={p:.2f}"
    else:
        omori_pred = float('nan')
        omori_str = "brak dopasowania (za malo danych)"

    n_obs = int((aft_t < t_f).sum())
    print(f"{t_f:6.2f} {window:6.2f} {n_obs:14d} {omori_str:>22} "
          f"{omori_pred:11.2f} {poisson_pred:12.2f} {naive_pred:10.2f} {real_count:7d}")
    results.append(dict(t_f=t_f, window=window, n_obs=n_obs, omori_pred=omori_pred,
                         poisson_pred=poisson_pred, naive_pred=naive_pred,
                         real=real_count))

# --- ocena: blad bezwzgledny kazdej metody wzgledem realnych obserwacji ---
import math
print("\n=== BLAD PROGNOZY (|pred - real|), im mniej tym lepiej ===")
sums = {'omori': 0.0, 'poisson': 0.0, 'naive': 0.0}
n = 0
for r in results:
    if math.isnan(r['omori_pred']):
        continue
    e_o = abs(r['omori_pred'] - r['real'])
    e_p = abs(r['poisson_pred'] - r['real'])
    e_n = abs(r['naive_pred'] - r['real'])
    sums['omori'] += e_o
    sums['poisson'] += e_p
    sums['naive'] += e_n
    n += 1
    print(f"t_f={r['t_f']:5.2f}d  Omori_err={e_o:6.2f}  Poisson_tlo_err={e_p:6.2f}  "
          f"naive24h_err={e_n:6.2f}  (real={r['real']})")

print(f"\nSrednia |blad| (n={n} punktow prognozy):")
for k, v in sums.items():
    print(f"  {k:10s}: {v/n:.2f}")
